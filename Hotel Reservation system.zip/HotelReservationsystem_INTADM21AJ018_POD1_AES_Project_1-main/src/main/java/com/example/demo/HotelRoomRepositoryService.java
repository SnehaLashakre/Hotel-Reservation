package com.example.demo;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import com.example.demo.Model.Room;
import org.springframework.jdbc.core.RowMapper;
@Service
public class HotelRoomRepositoryService {
	private static final Logger log = LoggerFactory.getLogger(HotelRoomRepositoryService.class);
	@Autowired
	public JdbcTemplate jdbcTemplate;

	public HotelRoomRepositoryService() {
	}

	public int executeInsert(Room room) {
		log.info("Exeucuting executeInsert");
		return jdbcTemplate.update(
				"INSERT INTO hotel_room(" + "room_number, " + "accomodation," + "room,description,"
						+ "number_person," + "price," + "picture" + ") VALUES (?,?,?,?,?,?,?)",
				room.getRoom_number(), room.getAccomodation(), room.getRoom(), room.getDescription(),
				room.getNumber_person(), room.getPrice(), room.getPicture());

	}

	public int executeUpdate(int id, double price) {
		log.info("Exeucuting executeUpdate");
		return jdbcTemplate.update("update hotel_room set price = ? WHERE id = ?", price, id);

	}

	public int executeDelete(int id) {
		log.info("Exeucuting executeDelete");
		return jdbcTemplate.update("DELETE FROM hotel_room WHERE id = ?", id);
	}

	@SuppressWarnings("deprecation")
	public List<Room> executeJDBCQueryById(int id) {
		log.info("Exeucuting executeJDBCQueryById");
		List<Room> room = jdbcTemplate.query("SELECT * FROM hotel_room where id = ?", new Object[] { id },
				(rs, rowNum) -> new Room(rs.getLong("id"), rs.getInt("room_number"), rs.getString("accomodation"),

						rs.getString("room"), rs.getString("description"), rs.getInt("number_person"),
						rs.getDouble("price"), rs.getString("picture")

				));
		return room;

	}

	@SuppressWarnings("deprecation")
	public List<Room> executeJDBCQuery() {
		log.info("Exeucuting executeJDBCQuery");
		List<Room> room = jdbcTemplate.query("SELECT * FROM hotel_room", new Object[] {},
				(rs, rowNum) -> new Room(
					rs.getLong("id"), rs.getInt("room_number"), rs.getString("accomodation"),

						rs.getString("room"), rs.getString("description"), rs.getInt("number_person"),
						rs.getDouble("price"), rs.getString("picture")

				));
		return room;

	}
		@SuppressWarnings("deprecation")
	public List<Map<String, String>> executeJDBCCheckRoomAvailabilityQuery(String check_in_date,
		String check_out_date,String room_accomodation) {
		log.info("Exeucuting executeJDBCQuery");
		List<Map<String, String>> reservation = jdbcTemplate.query("call check_room_availability(?,?,?)",
				new Object[] {check_in_date,check_out_date,room_accomodation}, new RowMapper<Map<String, String>>() {

					@Override
					public Map<String, String> mapRow(ResultSet rs, int index) throws SQLException {

						Map<String, String> mp = new HashMap<String, String>();

						mp.put("id", String.valueOf(rs.getInt("id")));
						mp.put("room_number", rs.getString("room_number"));
						mp.put("accomodation", rs.getString("accomodation"));
						mp.put("room", rs.getString("room"));
						mp.put("description", rs.getString("description"));
						mp.put("number_person", rs.getString("number_person"));
						mp.put("price", rs.getString("price"));
						mp.put("picture", rs.getString("picture"));
			

						return mp;
					}
				});
		return reservation;

	}
}