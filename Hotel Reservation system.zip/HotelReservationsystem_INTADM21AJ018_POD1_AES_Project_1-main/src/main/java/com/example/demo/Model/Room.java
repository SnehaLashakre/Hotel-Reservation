package com.example.demo.Model;

public class Room {
	private long id;
	private int room_number;
	private String accomodation;
	private String room;
	private String description;
	private int number_person;
	private double price;
	private String picture;
	

	public Room(long id, int room_number, String accomodation, String room, String description,
			int number_person, double price, String picture) {
		super();
		this.id = id;
		this.room_number = room_number;
		this.accomodation = accomodation;
		this.room = room;
		this.description = description;
		this.number_person = number_person;
		this.price = price;
		this.picture = picture;
	
	}


	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getRoom_number() {
		return room_number;
	}

	public void setRoom_number(int room_number) {
		this.room_number = room_number;
	}

	public String getAccomodation() {
		return accomodation;
	}

	public void setAccomodation(String accomodation) {
		this.accomodation = accomodation;
	}

	public String getRoom() {
		return room;
	}

	public void setRoom(String room) {
		this.room = room;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getNumber_person() {
		return number_person;
	}

	public void setNumber_person(int number_person) {
		this.number_person = number_person;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getPicture() {
		return picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	

	@Override
	public String toString() {
		return "Room [id=" + id + ", room_number=" + room_number + ", accomodation_id=" + accomodation + ", room="
				+ room + ", description=" + description + ", number_person=" + number_person + ", price=" + price
				+ ", picture=" + picture + "]";
	}
	
}