package com.example.demo;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import com.example.demo.Model.Reservation;
import com.example.demo.Model.Room;
import org.springframework.jdbc.core.RowMapper;

@Service
public class HotelReservationRepositoryService {
	private static final Logger log = LoggerFactory.getLogger(HotelReservationRepositoryService.class);
	@Autowired
	public JdbcTemplate jdbcTemplate;

	public HotelReservationRepositoryService() {
	}

	public int executeUpdate(int id,String status) {
		log.info("Exeucuting executeUpdate");
		System.out.println("update hotel_reservation set reservation_status = '" + status + "' WHERE id = " + id);
		return jdbcTemplate.update("update hotel_reservation set reservation_status = ? WHERE id = ?",
				status,id);
	}

	public int executeDelete(int id) {
		log.info("Exeucuting executeDelete");
		return jdbcTemplate.update("DELETE FROM hotel_room WHERE id = ?", id);
	}

	public int executeInsert(Reservation reservation) {
		log.info("Exeucuting executeInsert");
		return jdbcTemplate.update(
				"INSERT INTO hotel_reservation(room_id, arrival,departure,room_price,reservation_status,"
						+ "book_date,remark,user_id) VALUES (?,?,?,?,?,now(),?,?)",
				reservation.getRoom_id(), reservation.getArrival(), reservation.getDeparture(),
				reservation.getRoom_price(), reservation.getReservationStatus(), 
				reservation.getRemark(),reservation.getUser_id());

	}

	@SuppressWarnings("deprecation")
	public List<Map<String, String>> executeJDBCQueryById(int id) {
		log.info("Exeucuting executeJDBCQueryById");
		List<Map<String, String>> reservation = jdbcTemplate.query("call sp_retrieve_all_hotel_reservation_by_id(?)",
				new Object[] {id}, new RowMapper<Map<String, String>>() {

					@Override
					public Map<String, String> mapRow(ResultSet rs, int index) throws SQLException {

						Map<String, String> mp = new HashMap<String, String>();

						mp.put("id", String.valueOf(rs.getInt("id")));
						mp.put("room_id", rs.getString("room_id"));
						mp.put("arrival", rs.getString("arrival"));
						mp.put("departure", rs.getString("departure"));
						mp.put("room_price", rs.getString("room_price"));
						mp.put("reservation_status", rs.getString("reservation_status"));
						mp.put("book_date", rs.getString("book_date"));
						mp.put("remark", rs.getString("remark"));
						mp.put("user_id", rs.getString("user_id"));

						return mp;
					}
				});
		return reservation;

	}

	@SuppressWarnings("deprecation")
	public List<Map<String, String>> executeJDBCQueryByUserId(int userid) {
		log.info("Exeucuting executeJDBCQueryById");
		List<Map<String, String>> reservation = jdbcTemplate.query("call sp_retrieve_all_hotel_reservation_by_user(?)",
				new Object[] {userid}, new RowMapper<Map<String, String>>() {

					@Override
					public Map<String, String> mapRow(ResultSet rs, int index) throws SQLException {

						Map<String, String> mp = new HashMap<String, String>();

						mp.put("id", String.valueOf(rs.getInt("id")));
						mp.put("room_id", rs.getString("room_id"));
						mp.put("arrival", rs.getString("arrival"));
						mp.put("departure", rs.getString("departure"));
						mp.put("room_price", rs.getString("room_price"));
						mp.put("reservation_status", rs.getString("reservation_status"));
						mp.put("book_date", rs.getString("book_date"));
						mp.put("remark", rs.getString("remark"));
						mp.put("user_id", rs.getString("user_id"));

						return mp;
					}
				});
		return reservation;
	}
	@SuppressWarnings("deprecation")
	public List<Map<String, String>> executeJDBCQueryByRoomId(long roomId) {
		log.info("Exeucuting executeJDBCQueryById");
		List<Map<String, String>> reservation = jdbcTemplate.query("call sp_retrieve_all_hotel_reservation_by_room_id(?)",
				new Object[] {roomId}, new RowMapper<Map<String, String>>() {

					@Override
					public Map<String, String> mapRow(ResultSet rs, int index) throws SQLException {

						Map<String, String> mp = new HashMap<String, String>();

						mp.put("id", String.valueOf(rs.getInt("id")));
						mp.put("room_id", rs.getString("room_id"));
						mp.put("arrival", rs.getString("arrival"));
						mp.put("departure", rs.getString("departure"));
						mp.put("room_price", rs.getString("room_price"));
						mp.put("reservation_status", rs.getString("reservation_status"));
						mp.put("book_date", rs.getString("book_date"));
						mp.put("remark", rs.getString("remark"));
						mp.put("user_id", rs.getString("user_id"));

						return mp;
					}
				});
		return reservation;
	}

	@SuppressWarnings("deprecation")
	public List<Map<String, String>> executeJDBCQuery() {
		log.info("Exeucuting executeJDBCQuery");
		List<Map<String, String>> reservation = jdbcTemplate.query("call sp_retrieve_all_hotel_reservation()",
				new Object[] {}, new RowMapper<Map<String, String>>() {

					@Override
					public Map<String, String> mapRow(ResultSet rs, int index) throws SQLException {

						Map<String, String> mp = new HashMap<String, String>();

						mp.put("id", String.valueOf(rs.getInt("id")));
						mp.put("room_id", rs.getString("room_id"));
						mp.put("arrival", rs.getString("arrival"));
						mp.put("departure", rs.getString("departure"));
						mp.put("room_price", rs.getString("room_price"));
						mp.put("reservation_status", rs.getString("reservation_status"));
						mp.put("book_date", rs.getString("book_date"));
						mp.put("remark", rs.getString("remark"));
						mp.put("user_id", rs.getString("user_id"));

						return mp;
					}
				});
		return reservation;

	}


}