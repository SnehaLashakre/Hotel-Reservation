package com.example.demo;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.Model.Reservation;
import com.example.demo.Model.Room;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@CrossOrigin
@RestController
public class HotelReservationController {
	private static final Logger log = LoggerFactory.getLogger(HotelReservationController.class);
	@Autowired
	HotelReservationRepositoryService hotelReservationRepositoryService;

	@RequestMapping("/save_reservation")
	public HashMap<String, Object> saveReservatoin(@RequestParam("room_id") String room_id,
			@RequestParam("arrival") String arrival, @RequestParam("departure") String departure,
			@RequestParam("room_price") double room_price,
			@RequestParam("remark") String remark, @RequestParam("user_id") String user_id

	) {
		Reservation reservation = new Reservation(0, room_id, arrival, departure, room_price, "Pending", null, remark,
				user_id);
		int stat = hotelReservationRepositoryService.executeInsert(reservation);

		HashMap<String, Object> map = new HashMap<>();
		map.put("status", stat);
		return map;
	}

	/*
	 * 
	 * private long id; private String room_id; private String arrival; private
	 * String departure; private double room_price;
	 * 
	 * private String reservation_status; private String book_date; private String
	 * remark; private String user_id;
	 */
	@RequestMapping("/update_reservation")
	public HashMap<String, Object> updateReservation(
			@RequestParam("id") int id,
			@RequestParam("reservation_status") String reservation_status) {
		
		int stat = hotelReservationRepositoryService.executeUpdate(id,reservation_status);
		HashMap<String, Object> map = new HashMap<>();
		map.put("status", stat);
		return map;
	}

	@RequestMapping("/reservations")
	public List<Map<String, String>> retrieveAllReservation() {

		return hotelReservationRepositoryService.executeJDBCQuery();
	}

	@RequestMapping("/reservation/{id}")
	public List<Map<String, String>> retrieveReservationById(@PathVariable("id") int id) {

       log.info("id = " + id);
		return hotelReservationRepositoryService.executeJDBCQueryById(id);
	}

	@RequestMapping("/user_reservation/{userid}")
	public List<Map<String, String>> retrieveAllReservationByUser(@PathVariable("userid") int userid) {

		return hotelReservationRepositoryService.executeJDBCQueryByUserId(userid);
	}

}