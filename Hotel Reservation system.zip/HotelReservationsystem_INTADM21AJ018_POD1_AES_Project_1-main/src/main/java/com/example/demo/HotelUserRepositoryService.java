package com.example.demo;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.example.demo.Model.Room;
import com.example.demo.Model.User;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import org.springframework.jdbc.core.RowMapper;
@Service
public class HotelUserRepositoryService {
	private static final Logger log = LoggerFactory.getLogger(HotelUserRepositoryService.class);
	@Autowired
	public JdbcTemplate jdbcTemplate;

	public HotelUserRepositoryService() {
	}

	public int executeUpdate(User user) {
		log.info("Exeucuting executeUpdate");
		return jdbcTemplate.update(
				"update hotel_user " + "set first_name = ? AND" + " last_name = ? AND" + " gender= ? "
						+ "email = ? AND " + "mobile = ? AND " + "address = ? WHERE id = ?",
				user.getFirstName(), user.getLastName(), user.getGender(), user.getEmail(), user.getMobile(),
				user.getAddress(), user.getId());

	}

	public int executeDelete(int id) {
		log.info("Exeucuting executeDelete");
		return jdbcTemplate.update("DELETE FROM hotel_user WHERE id = ?", id);
	}

	public int executeInsert(User user) {
		log.info("Exeucuting executeInsert");
		return jdbcTemplate.update(
				"call sp_add_hotel_user(?,?,?,?,?,?,?,?)",
				user.getFirstName(), user.getLastName(), user.getGender(), user.getEmail(), user.getPassword(),
				user.getMobile(), user.getAddress(), user.getRole());

	}

	@SuppressWarnings("deprecation")
	public List<User> executeJDBCQueryById(int id) {
		log.info("Exeucuting executeJDBCQueryById");
		List<User> user = jdbcTemplate.query("SELECT * FROM hotel_user where id = ?", new Object[] { id },
				(rs, rowNum) -> new User(rs.getLong("id"), rs.getString("first_name"), rs.getString("last_name"),
						rs.getString("gender"), rs.getString("email"), rs.getString("password"), rs.getString("mobile"),
						rs.getString("address"), rs.getString("created"), rs.getString("role")

				));
		return user;

	}

	@SuppressWarnings("deprecation")
	public List<User> executeJDBCQuery() {
		log.info("Exeucuting executeJDBCQuery");
		List<User> user = jdbcTemplate.query("SELECT * FROM hotel_user", new Object[] {},
				(rs, rowNum) -> new User(rs.getLong("id"), rs.getString("first_name"), rs.getString("last_name"),
						rs.getString("gender"), rs.getString("email"), rs.getString("password"), rs.getString("mobile"),
						rs.getString("address"), rs.getString("created"), rs.getString("role")

				));
		return user;

	}
	@SuppressWarnings("deprecation")
	public List<User> executeJDBCQueryLogin(String username,String password) {
		log.info("Exeucuting executeJDBCQueryLogin");
		List<User> user = jdbcTemplate.query("SELECT * FROM hotel_user where email = ? and password = ?", new Object[] {username,password},
				(rs, rowNum) -> new User(rs.getLong("id"), rs.getString("first_name"), rs.getString("last_name"),
						rs.getString("gender"), rs.getString("email"), rs.getString("password"), rs.getString("mobile"),
						rs.getString("address"), rs.getString("created"), rs.getString("role")

				));
		return user;

	}

	public List<Map<String,String>> executeJDBCQueryDashCount(){
		return jdbcTemplate.query("call sp_dash_count()",
				new Object[] {}, new RowMapper<Map<String, String>>() {

					@Override
					public Map<String, String> mapRow(ResultSet rs, int index) throws SQLException {

						Map<String, String> mp = new HashMap<String, String>();

						mp.put("total_user", String.valueOf(rs.getInt("total_user")));
						mp.put("total_room", String.valueOf(rs.getInt("total_room")));
						mp.put("total_confirmed_reservation", String.valueOf(rs.getInt("total_confirmed_reservation")));
						mp.put("total_cancelled_reservation", String.valueOf(rs.getInt("total_cancelled_reservation")));
			
			

						return mp;
					}
				});
	}
}