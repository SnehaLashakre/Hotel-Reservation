import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RequestService {

  constructor(private http : HttpClient) { }

  postData(url,formdata) : Observable<Object[]>{
   return this.http.post<Object[]>(url, formdata);
  }
  getData(url){
    return this.http.get(url);
  }
}
