import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { ToastService } from '../../toast.service';
import { Room } from '../Model/Room';

@Component({
  templateUrl: 'room-details.component.html'
})
export class RoomDetailsComponent {
  roomDetails: Room
  addressQueries = ""
  constructor(public toastService: ToastService,private domSanitizer: DomSanitizer,
    private http: HttpClient, private router: Router) {
    console.log(this.roomDetails)
    this.load_room_details()
  }
  showSuccess(msg) {
    this.toastService.show(msg, {
      classname: 'bg-success text-light',
      delay: 2000,
      autohide: true,
      headertext: 'Toast Header'
    });
  }
  showError(msg) {
    this.toastService.show(msg, {
      classname: 'bg-danger text-light',
      delay: 2000,
      autohide: true,
      headertext: 'Error!!!'
    });
  }
  async load_room_details() {
    let room_id = sessionStorage.getItem("selected_room_id");
    let response = await this.http.get<Room[]>("http://localhost:8080/room/" + room_id).toPromise()
    let userLoggedIn = sessionStorage.getItem("user-loggedIn");
    if (userLoggedIn == "true") {

    }
    else {
      this.router.navigate(['/user/login']);
    }
    this.roomDetails = response[0]
    console.log(this.roomDetails)
  }
  async book_now() {
    let user_address = sessionStorage.getItem("user-address")
    console.log(user_address)
    console.log("address q = " + this.addressQueries)
    if(this.addressQueries == user_address){

   
    
    let user_id = sessionStorage.getItem("user-id");
    let check_in_date = sessionStorage.getItem("check_in_date");
    let check_out_date = sessionStorage.getItem("check_in_date");
    let param = new FormData();
    param.append("room_id", this.roomDetails.id.toString())
    param.append("arrival", check_in_date);
    param.append("departure", check_out_date);
    param.append("room_price", this.roomDetails.price.toString())
    param.append("remark", "Room Booked")
    param.append("user_id", user_id)

    let response = await this.http.post("http://localhost:8080/save_reservation",param).toPromise()
    console.log(response)
    if(response["status"] == "1"){
      this.showSuccess("Room Booked Successfully");
      this.router.navigate(["/user/dashboard"]);
    }
    else{
      this.showSuccess("Room Booking Successfully");
    }
  }
  else{
    this.showSuccess("Proivded and Stored address different.Please Verify address");
  }
  }
}
