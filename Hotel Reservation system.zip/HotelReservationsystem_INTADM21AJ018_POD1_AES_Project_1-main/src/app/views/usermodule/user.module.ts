// Angular
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

// Alert Component
import { AlertModule } from 'ngx-bootstrap/alert';


import { RoomDetailsComponent } from './room-details.component';

// Modal Component
import { ModalModule } from 'ngx-bootstrap/modal';
import { ViewBookRoomsComponent } from './view-book-rooms.component';
import { FormsModule } from '@angular/forms';
// Notifications Routing
import { UserRoutingModule } from './user-routing.module';
import {UserAuthGuard} from './UserAuthGuard';
import { UserDashboardComponent } from './dashboard.component';
import { LoginComponent } from './login.component';
import { RegisterComponent } from './register.component';
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    UserRoutingModule,
    AlertModule.forRoot(),
    ModalModule.forRoot()
  ],
  declarations: [
    UserDashboardComponent,
    RoomDetailsComponent,
    LoginComponent,
    RegisterComponent,
    ViewBookRoomsComponent
  ],
  
  providers: [UserAuthGuard],
})
export class UserModule { }
