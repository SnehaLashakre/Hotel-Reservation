import { Injectable } from '@angular/core';
import { CanActivate, CanActivateChild, Router } from '@angular/router';

@Injectable()
export class UserAuthGuard implements CanActivate, CanActivateChild {
  constructor(private router: Router){
    
  }
  canActivate() {
    //ask if he really wants to route.
    sessionStorage.setItem("user-session","user");
    console.log('i am checking to see if you are User is logged ')
    //this.router.navigate(['/adminlogin']);
    return true;
  }

  canActivateChild() {
    console.log('checking child route access');
    return true;
  }

}