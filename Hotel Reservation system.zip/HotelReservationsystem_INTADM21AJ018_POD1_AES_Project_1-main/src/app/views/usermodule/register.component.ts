import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ToastService } from '../../toast.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: 'register.component.html'
})
export class RegisterComponent {
  first_name: ""

  user = {
    first_name: "",
    last_name: "",
    gender: "",
    email: "",
    password: "",
    confirm_password: "",
    address: "",
    mobile: ""

  }
  constructor(public toastService: ToastService,private http: HttpClient, private router: Router) { }

  showSuccess(msg) {
    this.toastService.show(msg, {
      classname: 'bg-success text-light',
      delay: 2000,
      autohide: true,
      headertext: 'Toast Header'
    });
  }
  showError(msg) {
    this.toastService.show(msg, {
      classname: 'bg-danger text-light',
      delay: 2000,
      autohide: true,
      headertext: 'Error!!!'
    });
  }
  async register() {
    console.log("register " + this.first_name)
    console.log(this.user);
    let param: FormData = new FormData();
    param.append("first_name", this.user.first_name)
    param.append("last_name", this.user.last_name)
    param.append("gender", this.user.gender);
    param.append("email", this.user.email);
    param.append("password", this.user.password);
    param.append("confirm_password", this.user.confirm_password)
    param.append("address", this.user.address);
    param.append("mobile", this.user.mobile);
    param.append("role","user");
    let response = await this.http.post("http://localhost:8080/add_user", param).toPromise();
    console.log(response);
    if(response["status"] == 1){
      this.showSuccess("User Registered Successfully")
      this.router.navigate(["/user/login"])
    }
    else{
      this.showError("User Registration Failed")
    }

  }

}
