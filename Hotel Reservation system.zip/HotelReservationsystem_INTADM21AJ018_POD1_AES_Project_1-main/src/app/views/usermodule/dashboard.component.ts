import { Component, OnInit } from '@angular/core';
import { getStyle, hexToRgba } from '@coreui/coreui/dist/js/coreui-utilities';
import { CustomTooltips } from '@coreui/coreui-plugin-chartjs-custom-tooltips';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Room } from '../Model/Room';
import { DomSanitizer } from '@angular/platform-browser';
import { ToastService } from '../../toast.service';

@Component({
  templateUrl: 'dashboard.component.html',
  styleUrls: ['dashboard.component.css']
})
export class UserDashboardComponent  {
   
   roomCheckIn = {
     arrival : "",
     depature : "",
     number_person : ""
   }
   check_avail = {
    check_in_date : "",
    check_out_date : "",
    room_accomodation  : ""
   }
   rooms : Room[]= [
     
   ]
   constructor(private toastService : ToastService,private domSanitizer: DomSanitizer,private http : HttpClient,private router : Router){
   // this.loadRoom();
   }
   showSuccess(msg) {
    this.toastService.show(msg, {
      classname: 'bg-success text-light',
      delay: 2000,
      autohide: true,
      headertext: 'Toast Header'
    });
  }
  showError(msg) {
    this.toastService.show(msg, {
      classname: 'bg-danger text-light',
      delay: 2000,
      autohide: true,
      headertext: 'Error!!!'
    });
  }
   book_now(room_id){
     sessionStorage.setItem("selected_room_id",room_id)
    this.router.navigate(['/user/room-details']);
   }
   async check_room_availability(){
    let params = new FormData();
    params.append("check_in_date",this.check_avail.check_in_date);
    params.append("check_out_date",this.check_avail.check_out_date);
    params.append("room_accomodation"
    ,this.check_avail.room_accomodation);

    sessionStorage.setItem("check_in_date",this.check_avail.check_in_date);
    sessionStorage.setItem("check_out_date",this.check_avail.check_out_date);

    let response = await this.http.post<Room[]>("http://localhost:8080/check_room_availability",params).toPromise();
    console.log(response);
    this.rooms = response;
    if(this.rooms.length < 0){
       this.showError("No Room Available")
    }
   }
   
}
