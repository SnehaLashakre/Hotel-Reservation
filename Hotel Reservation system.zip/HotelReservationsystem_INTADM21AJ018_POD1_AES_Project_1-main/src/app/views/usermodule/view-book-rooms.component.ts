import { HttpClient } from '@angular/common/http';
import { Component, ViewChild } from '@angular/core';
import { ToastService } from '../../toast.service';

interface Reservation {
  room: string;
  arrival: string;
  depature: string;
  room_price: number;
  status: string;
  user: string;
  book_date: string;

}
const RESERVATIONS: Reservation[] = [
  {
    room: "Standard date",
    arrival: "13/06/2021",
    depature: "14/06/2021",
    room_price: 2200,
    status: "Pending",
    user: "james",
    book_date: "13/06/2021"
  }
]
@Component({
  templateUrl: 'view-book-rooms.component.html'
})
export class ViewBookRoomsComponent {
  page = 1;
  pageSize = 4;
  collectionSize 
  fullReservation :  Reservation[];
  reservations: Reservation[];
  constructor(public toastService: ToastService,private http : HttpClient) {
    this.loadReservation();
  }
  showSuccess(msg) {
    this.toastService.show(msg, {
      classname: 'bg-success text-light',
      delay: 2000,
      autohide: true,
      headertext: 'Toast Header'
    });
  }
  showError(msg) {
    this.toastService.show(msg, {
      classname: 'bg-danger text-light',
      delay: 2000,
      autohide: true,
      headertext: 'Error!!!'
    });
  }
  async loadReservation() {
    let userid = sessionStorage.getItem("user-id")
    let response = await this.http.get<Reservation[]>("http://localhost:8080/user_reservation/" + userid).toPromise()
    this.collectionSize = response.length;
    console.log(response);
    this.fullReservation = response;
    this.reservations = response
      .map((reservation, i) => ({id: i + 1, ...reservation}))
      .slice((this.page - 1) * this.pageSize, (this.page - 1) * this.pageSize + this.pageSize);
  }
  refreshReservation(){
    this.reservations = this.fullReservation
      .map((reservation, i) => ({ id: i + 1, ...reservation }))
      .slice((this.page - 1) * this.pageSize, (this.page - 1) * this.pageSize + this.pageSize);
  }
  async cancel_booking(id){
    let param = new FormData();
    param.append("id",id);
    param.append("reservation_status","Cancelled");
    let response = await this.http.post("http://localhost:8080/update_reservation",param).toPromise()
    this.loadReservation();
    console.log(response);
    if(response["status"] == 1){
        this.showSuccess("Reservation Cancelled Successully");
    }
    else{
      this.showSuccess("Reservation Cancell Failed");
    }
  }
 
}
