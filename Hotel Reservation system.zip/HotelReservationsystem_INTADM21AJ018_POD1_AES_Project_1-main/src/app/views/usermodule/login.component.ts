import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ToastService } from '../../toast.service';
import { User } from '../Model/User';

@Component({
  selector: 'app-dashboard',
  templateUrl: 'login.component.html'
})
export class LoginComponent {

  user = {
    email: "",
    password: ""
  }
  constructor(public toastService: ToastService,private http: HttpClient, private router: Router) {

  }
  showSuccess(msg) {
    this.toastService.show(msg, {
      classname: 'bg-success text-light',
      delay: 2000,
      autohide: true,
      headertext: 'Toast Header'
    });
  }
  showError(msg) {
    this.toastService.show(msg, {
      classname: 'bg-danger text-light',
      delay: 2000,
      autohide: true,
      headertext: 'Error!!!'
    });
  }
  async login() {
    let param = new FormData();
    param.append("username", this.user.email);
    param.append("password", this.user.password);

    let response = await this.http.post<User[]>("http://localhost:8080/userlogin", param).toPromise();
    if (response.length > 0) {
        sessionStorage.setItem("role", "user");
        sessionStorage.setItem("email", this.user.email);
        sessionStorage.setItem("user-email",this.user.email);
        sessionStorage.setItem("user-id", response[0].id.toString());
        sessionStorage.setItem("user-address",response[0].address)
        sessionStorage.setItem("user-loggedIn", "true");
        this.showSuccess("User LoggedIn Successfully")
        this.router.navigate(["/user/dashboard"]) 
    }
    else {
      this.showError("User LoggedIn Failed");
      sessionStorage.setItem("user-loggedIn", "false");
    }
    console.log(response);
  }
  redirect_register() {


    this.router.navigate(["/user/register"])
  }
}
