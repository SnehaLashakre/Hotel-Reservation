import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserDashboardComponent } from './dashboard.component';


import { RoomDetailsComponent } from './room-details.component';
import { ViewBookRoomsComponent } from './view-book-rooms.component';
import {UserAuthGuard} from './UserAuthGuard'
import { LoginComponent } from './login.component';
import { RegisterComponent } from './register.component';
const routes: Routes = [
      {
        path: '',
        redirectTo: 'dashboard'
      },
      {
        path: 'dashboard',
        component: UserDashboardComponent,
        data: {
          title: 'User Dashboard'
        }
        ,
        canActivate:[UserAuthGuard]
      },
      {
        path: 'room-details',
        component: RoomDetailsComponent,
        data: {
          title: 'Room Details'
        }
      },
      {
        path: 'view-book-room',
        component: ViewBookRoomsComponent,
        data: {
          title: 'View Booked Rooms'
        }
      },
      {
        path: 'login',
        component: LoginComponent,
        data: {
          title: 'User Login'
        }
      },
      {
        path: 'register',
        component: RegisterComponent,
        data: {
          title: 'User Register'
        }
      },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserRoutingModule {}
