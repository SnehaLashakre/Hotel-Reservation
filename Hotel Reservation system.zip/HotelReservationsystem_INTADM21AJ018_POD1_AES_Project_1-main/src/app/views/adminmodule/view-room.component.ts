import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { ToastService } from '../../toast.service';
import { Room } from '../Model/Room';


@Component({
  templateUrl: 'view-room.component.html',
  styleUrls: ['view-room.component.css']
})
export class ViewRoomComponent {

  page = 1;
  pageSize = 4;
  collectionSize
  fullRoom : Room[];
  rooms: Room[];
  constructor(private toastService : ToastService, private http : HttpClient) {
    this.loadRoom();
  }
  async loadRoom() {
    let response = await this.http.get<Room[]>("http://localhost:8080/rooms").toPromise();
    console.log(response);
    this.collectionSize = response.length;
    this.fullRoom = response;
    this.rooms = response
      .map((room, i) => ({id: i + 1, ...room}))
      .slice((this.page - 1) * this.pageSize, (this.page - 1) * this.pageSize + this.pageSize);

  }
  refreshRoom(){
    this.rooms = this.fullRoom
    .map((room, i) => ({id: i + 1, ...room}))
    .slice((this.page - 1) * this.pageSize, (this.page - 1) * this.pageSize + this.pageSize);
  }
  showSuccess(msg) {
    this.toastService.show(msg, {
      classname: 'bg-success text-light',
      delay: 2000,
      autohide: true,
      headertext: 'Toast Header'
    });
  }
  showError(msg) {
    this.toastService.show(msg, {
      classname: 'bg-danger text-light',
      delay: 2000,
      autohide: true,
      headertext: 'Error!!!'
    });
  }
  async delete_room(id){
    let response = await this.http.get<Room[]>("http://localhost:8080/delete_room/" + id).toPromise();
    console.log(response);
    if(response["status"] == 1){
      this.showSuccess("Room Deleted Successfully");
      this.loadRoom()
    }
    else{
      this.showSuccess("Room Deletion Failed");
    }
  }
}
