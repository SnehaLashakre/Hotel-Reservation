import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { ToastService } from '../../toast.service';
import {User} from '../Model/User';

@Component({
  templateUrl: 'view-user.component.html'
})
export class ViewUserComponent {

  page = 1;
  pageSize = 4;
  collectionSize 
  users: User[];
  fullusers: User[];
  constructor(private toastService : ToastService,private http : HttpClient) {
    this.loadUsers();
  }
  showSuccess(msg) {
    this.toastService.show(msg, {
      classname: 'bg-success text-light',
      delay: 2000,
      autohide: true,
      headertext: 'Toast Header'
    });
  }
  showError(msg) {
    this.toastService.show(msg, {
      classname: 'bg-danger text-light',
      delay: 2000,
      autohide: true,
      headertext: 'Error!!!'
    });
  }

  async loadUsers() {
    let response = await this.http.get<User[]>("http://localhost:8080/users").toPromise();
    console.log(response);
    this.collectionSize = response.length;
    this.fullusers = response;
    this.users = response
      .map((user, i) => ({id: i + 1, ...user}))
      .slice((this.page - 1) * this.pageSize, (this.page - 1) * this.pageSize + this.pageSize);
  }

   refreshUser(){
    
    this.users =this.fullusers 
      .map((user, i) => ({id: i + 1, ...user}))
      .slice((this.page - 1) * this.pageSize, (this.page - 1) * this.pageSize + this.pageSize);
  
  }
}
