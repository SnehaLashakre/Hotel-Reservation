import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AddRoomComponent } from './add-room.component';
import { ViewRoomComponent } from './view-room.component';
import { ReservationComponent } from './reservation.component';
import { DashboardComponent } from './dashboard.component';
import {AdminAuthGuard} from './AdminAuthGuard';
import { ViewUserComponent } from './view-user.component';
const routes: Routes = [
  {
    path: '',
    component: DashboardComponent,
    data: {
      title: 'Dropdowns'
    },
    canActivate:[AdminAuthGuard]
  },
    {
      path: 'addroom',
      component: AddRoomComponent,
      data: {
        title: 'Add Rooms'
      },
      canActivate:[AdminAuthGuard]
    },
    {
      path: 'viewuser',
      component: ViewUserComponent,
      data: {
        title: 'View User'
      },
      canActivate:[AdminAuthGuard]
    },
    {
      path: 'viewroom',
      component: ViewRoomComponent,
      data: {
        title: 'View Rooms'
      },
      canActivate:[AdminAuthGuard]
    },
    {
      path: 'reservation',
      component: ReservationComponent,
      data: {
        title: 'View Reservatoion'
      },
      canActivate:[AdminAuthGuard]
    },
    {
      path: 'dashboard',
      component: DashboardComponent,
      data: {
        title: 'Dashboard'
      },
      canActivate:[AdminAuthGuard]
    }
  
    
  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule {}
