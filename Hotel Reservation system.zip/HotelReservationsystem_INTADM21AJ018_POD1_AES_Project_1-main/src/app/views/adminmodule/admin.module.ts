import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';

import { AddRoomComponent } from './add-room.component';
import { ViewRoomComponent } from './view-room.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
// Dropdowns Component
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';

import { DashboardComponent } from './dashboard.component';
// Buttons Routing
import { AdminRoutingModule } from './admin-routing.module';
import {AdminAuthGuard} from './AdminAuthGuard';
import { ReservationComponent } from './reservation.component';
import { ViewUserComponent } from './view-user.component';
// Angular

@NgModule({
  imports: [
    CommonModule,
    AdminRoutingModule,
    BsDropdownModule.forRoot(),
    FormsModule,
    NgbModule
  ],
  declarations: [
    AddRoomComponent,
    ViewRoomComponent,
    ViewUserComponent,
    ReservationComponent,
    DashboardComponent
   
  ],
  providers: [AdminAuthGuard],
})
export class AdminModule { }
