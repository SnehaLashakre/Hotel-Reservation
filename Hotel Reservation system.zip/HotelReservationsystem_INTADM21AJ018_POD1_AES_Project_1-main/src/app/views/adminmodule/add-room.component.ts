import { Component, OnDestroy } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { RequestService } from '../../request.service';
import { ToastService } from '../../toast.service';
import { Router } from '@angular/router';
@Component({
  templateUrl: 'add-room.component.html',
  styleUrls: ['add-room.component.css']
})
export class AddRoomComponent {

  room = {
    room_number: "",
    accomodation_id: "1",
    room: "",
    description: "",
    number_person: "",
    price: "",

  }
  errorText = ""
  selectedRoomImage: File;
  imgURL
  constructor(public toastService: ToastService, 
    
      private router : Router,
    private requestService: RequestService) { }

  showSuccess(msg) {
    this.toastService.show(msg, {
      classname: 'bg-success text-light',
      delay: 2000,
      autohide: true,
      headertext: 'Toast Header'
    });
  }
  showError(msg) {
    this.toastService.show(msg, {
      classname: 'bg-danger text-light',
      delay: 2000,
      autohide: true,
      headertext: 'Error!!!'
    });
  }
  selectFile(event) {

    console.log(event)
    const file = event.target.files.item(0)
    console.log(file)
    if (file.type.match('image.*')) {
      this.selectedRoomImage = file;
    } else {
      alert('invalid format!');
    }
    var reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (_event) => {
      this.imgURL = reader.result;
    }
    console.log(this.selectedRoomImage)
  }
  async AddRoom() {

    if (this.room.accomodation_id == "" ||
      this.room.room == "" ||
      this.room.price == "" ||
      this.room.number_person == "" ||
      this.room.description == "" ||
      this.room.room_number == "" ||
      this.selectedRoomImage == null
    ) {
      this.errorText = "Please fill required fields";
    }
    else {
      let formdata: FormData = new FormData();
      formdata.append("accomodation", this.room.accomodation_id);
      formdata.append("room", this.room.room);
      formdata.append("price", this.room.price)
      formdata.append("number_person", this.room.number_person);
      formdata.append("description", this.room.description);
      formdata.append("room_number", this.room.room_number);
      formdata.append('picture', this.selectedRoomImage);
      let response = await this.requestService.postData("http://localhost:8080/add_room", formdata).toPromise()
      console.log(response)
      console.log(response["status"])
      console.log(response["status"] == 1)
      if(response["status"] == 1){
      console.log("room added success")
        this.showSuccess("Added Room Successfully")
        this.router.navigate(["/admin/viewroom"]);
      }
      else{
        this.showError("Adding Room Failed");
      }

    }
  }
}
