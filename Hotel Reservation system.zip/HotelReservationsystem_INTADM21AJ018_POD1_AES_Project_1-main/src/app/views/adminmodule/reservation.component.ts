import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { ToastService } from '../../toast.service';
import { Reservation } from '../Model/Reservation';



@Component({
  templateUrl: 'reservation.component.html',
  styleUrls: ['reservation.component.css']
})
export class ReservationComponent {
  page = 1;
  pageSize = 4;
  collectionSize
  reservations: Reservation[];
  fullReservation : Reservation[];
  constructor(private toastService: ToastService, private http: HttpClient) {
    this.loadReservation();
  }
  showSuccess(msg) {
    this.toastService.show(msg, {
      classname: 'bg-success text-light',
      delay: 2000,
      autohide: true,
      headertext: 'Toast Header'
    });
  }
  showError(msg) {
    this.toastService.show(msg, {
      classname: 'bg-danger text-light',
      delay: 2000,
      autohide: true,
      headertext: 'Error!!!'
    });
  }
  async loadReservation() {
    let response = await this.http.get<Reservation[]>("http://localhost:8080/reservations").toPromise()
    this.collectionSize = response.length;
    console.log(response);
    this.fullReservation = response
    this.reservations = response
      .map((reservation, i) => ({ id: i + 1, ...reservation }))
      .slice((this.page - 1) * this.pageSize, (this.page - 1) * this.pageSize + this.pageSize);
  }
  
  refreshReservation(){
    this.reservations = this.fullReservation
      .map((reservation, i) => ({ id: i + 1, ...reservation }))
      .slice((this.page - 1) * this.pageSize, (this.page - 1) * this.pageSize + this.pageSize);
  }
  async confirm_now(id) {
    let param = new FormData();
 
    param.append("id", id.toString());
    param.append("reservation_status", "Confirmed");
    let response = await this.http.post("http://localhost:8080/update_reservation", param).toPromise();
    console.log(response);

    if (response["status"] == 1) {
      this.loadReservation();
      this.showSuccess("Confirmed Successfully")
    }
    else {
      this.showError("Rejection Failed");
    }
  }
  async reject_now(id) {
    let param = new FormData();
  
    param.append("id",id.toString());
    param.append("reservation_status", "Rejected");
    let response = await this.http.post("http://localhost:8080/update_reservation", param).toPromise();
    console.log(response);

    if (response["status"] == 1) {
      this.loadReservation();
      this.showSuccess("Rejected Successfully")
    }
    else {
      this.showError("Rejection Failed")
    }
  }
}
