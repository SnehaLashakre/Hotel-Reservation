import { Injectable } from '@angular/core';
import { CanActivate, CanActivateChild, Router } from '@angular/router';

@Injectable()
export class AdminAuthGuard implements CanActivate, CanActivateChild {
  constructor(private router: Router){
    
  }
  canActivate() {
    //ask if he really wants to route.
    sessionStorage.setItem("user-session","admin");
    let userLoggedIn = sessionStorage.getItem("user-loggedIn");
    if(userLoggedIn == "true"){
      return true;
    }
    else{
      this.router.navigate(['/adminlogin']);
      return false;
    }
    console.log('i am checking to see if you are  Admin logged ')
    //
  
  }

  canActivateChild() {
    console.log('checking child route access');
    return true;
  }

}