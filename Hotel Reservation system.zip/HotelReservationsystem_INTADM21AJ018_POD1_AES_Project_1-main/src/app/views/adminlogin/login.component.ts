import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { RequestService } from '../../request.service';
import { ToastService } from '../../toast.service';
import { User } from '../Model/User';

@Component({
  selector: 'app-dashboard',
  templateUrl: 'login.component.html'
})
export class LoginComponent {

  user = {
    userName: "",
    passWord: ""
  }
  constructor(public toastService: ToastService, private http: HttpClient, private router: Router) {

  }

  showSuccess(msg) {
    this.toastService.show(msg, {
      classname: 'bg-success text-light',
      delay: 2000,
      autohide: true,
      headertext: 'Toast Header'
    });
  }
  showError(msg) {
    this.toastService.show(msg, {
      classname: 'bg-danger text-light',
      delay: 2000,
      autohide: true,
      headertext: 'Error!!!'
    });
  }


  async Login() {

    let formdata: FormData = new FormData();
    formdata.append("username", this.user.userName);
    formdata.append("password", this.user.passWord);

  
    let response = await this.http.post<User[]>("http://localhost:8080/userlogin", formdata).toPromise();

    if (response.length > 0) {
      this.showSuccess("Admin LoggedIn Successfully");
      let responseObject = response[0];
      console.log(responseObject)

      let id = responseObject.id
      let email = responseObject.email;
      let role = responseObject.role;

      sessionStorage.setItem("user-session", role);
      sessionStorage.setItem("user-id", id.toString());
      sessionStorage.setItem("user-email", email);
      sessionStorage.setItem("user-loggedIn", "true");
      this.router.navigate(['/admin/dashboard']);
    }
    else {
      this.showError("Admin LoggedIn Failed")
    }

  }
}
