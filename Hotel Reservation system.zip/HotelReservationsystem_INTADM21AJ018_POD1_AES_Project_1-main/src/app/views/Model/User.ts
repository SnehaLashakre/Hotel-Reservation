export interface User {
    id : number;
    firstName: string;
    lastName: string;
    gender: string;
    email: string;
    mobile: string;
    address : string;
    role : string;
  }