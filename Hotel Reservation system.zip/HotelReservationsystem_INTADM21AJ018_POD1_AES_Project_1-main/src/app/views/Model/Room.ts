export interface Room {
 id : number;
    room_number: number;
    accomodation: string;
    room: string;
    description: string;
    number_person: number;
    price : number;
    picture : String;
  }