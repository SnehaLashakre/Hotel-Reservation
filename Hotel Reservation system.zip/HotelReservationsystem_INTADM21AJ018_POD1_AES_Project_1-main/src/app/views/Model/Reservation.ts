export interface Reservation {
    id : number;
    room_id: string;
    arrival : string;
    departure : string;
    room_price : number;
    reservation_status : string;
    user_id: string;
    book_date : string;
  
  }