import { INavData } from '@coreui/angular';

export const navUserItems: INavData[] = [
  {
    name: 'Dashboard',
    url: '/user/dashboard',
    icon: 'icon-speedometer'

  }, 
  {
    name: 'View Booked Rooms',
    url: '/user/view-book-room',
    icon: 'icon-pie-chart'
  },
];
