import { INavData } from '@coreui/angular';

export const navAdminItems: INavData[] = [
  {
    name: 'Dashboard',
    url: '/admin/dashboard',
    icon: 'icon-speedometer'

  }, 
  {
    name: 'Add Rooms',
    url: '/admin/addroom',
    icon: 'icon-cursor'
  },
  {
    name: 'View Rooms',
    url: '/admin/viewroom',
    icon: 'icon-cursor'
  },
  {
    name: 'View User',
    url: '/admin/viewuser',
    icon: 'icon-cursor'
  },
  {
    name: 'Reservation',
    url: '/admin/reservation',
    icon: 'icon-pie-chart'
  },
];
