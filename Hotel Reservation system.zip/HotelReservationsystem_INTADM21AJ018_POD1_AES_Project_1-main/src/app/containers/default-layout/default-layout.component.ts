import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ToastService } from '../../toast.service';
import { navAdminItems } from '../../_admin_nav';
import { navUserItems } from '../../_user_nav';
@Component({
  selector: 'app-dashboard',
  templateUrl: './default-layout.component.html'
})
export class DefaultLayoutComponent {
  public sidebarMinimized = false;
  userSessionValue = sessionStorage.getItem("user-session");
  public navItems = this.userSessionValue == "admin" ? navAdminItems : navUserItems;
  user_email
  user_role
  isShowDropDown = false;
  constructor(public toastService: ToastService, private router: Router) {
     this.user_email = sessionStorage.getItem("user-email");
     this.user_role = sessionStorage.getItem("user-session");

  }
  showSuccess(msg) {
    this.toastService.show(msg, {
      classname: 'bg-success text-light',
      delay: 2000,
      autohide: true,
      headertext: ''
    });
  }
  toggleMinimize(e) {
    this.sidebarMinimized = e;
  }
  Logout() {
    sessionStorage.clear();
    this.showSuccess("Logout Successfully");
    let userRole = sessionStorage.getItem("user-session");
    alert("userRole" + userRole)
    if(userRole == "user"){
      this.router.navigate(['/user/dashboard']);
    }
    else{
      this.router.navigate(['/adminlogin']);
    }

 
  }
}
