package com.example.demo;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.Model.Room;
import com.example.demo.HotelRoomRepositoryService;

import org.springframework.beans.factory.annotation.Autowired;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;

import java.util.*;
@CrossOrigin
@RestController
public class HotelRoomController {
	private static final Logger log = LoggerFactory.getLogger(HotelRoomController.class);
	@Autowired
	HotelRoomRepositoryService hotelRoomRepositoryService;
	@Autowired
	HotelReservationRepositoryService hotelReservationRepositoryService;
	@RequestMapping("/add_room")  //story 5 from sprint 2
	public HashMap<String, Object> AddRoom(
			@RequestParam("accomodation") String accomodation,
			@RequestParam("price") double price,
			@RequestParam("room") String room,
				@RequestParam("number_person") int number_person,
					@RequestParam("description") String description,
						@RequestParam("room_number") int room_number,
							@RequestParam("picture") MultipartFile file

			) {
		String encodedStr = "";
		try {
			encodedStr = Base64.getEncoder().encodeToString(file.getBytes());
		} catch (IOException e) {
			e.printStackTrace();
		}

		System.out.println("encodedStr " + encodedStr);
		Room roomo = new Room(0,room_number,accomodation,room,description,number_person,price,"data:image/png;base64, " + encodedStr);
		int stat = hotelRoomRepositoryService.executeInsert(roomo);
		
		HashMap<String, Object> map = new HashMap<>();
		map.put("status", stat);
		return map;
	}


	@RequestMapping("/check_room_availability")
	public List<Room> executeJDBCCheckRoomAvailabilityQuery(@RequestParam("check_in_date") String check_in_date,
@RequestParam("check_out_date") String check_out_date,
@RequestParam("room_accomodation") String room_accomodation
		) {
		List<Room> availableRoom = new ArrayList<Room>();
		List<Room> roomList = hotelRoomRepositoryService.executeJDBCQuery();
		log.info("RoomList = " + roomList.toString());
		for(int i =0;i < roomList.size();i++){
			Room room = roomList.get(i);
			List<Map<String, String>>  mapList = hotelReservationRepositoryService.executeJDBCQueryByRoomId(room.getId());
			log.info("mapList2 = " + mapList.toString());
			if(mapList.size() > 0){
					List<Map<String,String>> avaList = hotelRoomRepositoryService.executeJDBCCheckRoomAvailabilityQuery(check_in_date,check_out_date,room_accomodation);
					log.info("avaList = " + avaList.toString());
					if(avaList.size() > 0){
						availableRoom.add(room);
					}

			}
			else{
				availableRoom.add(room);
			}
		}
		return availableRoom;
	}
	@RequestMapping("/room/{id}")
	public List<Room> getHoteRoomById(@PathVariable(value = "id") int id) {
		return hotelRoomRepositoryService.executeJDBCQueryById(id);
	}

	@RequestMapping("/rooms")
	public List<Room> getAllHotelRooms() {
		return hotelRoomRepositoryService.executeJDBCQuery();
	}
//Story 4 from Sprint 2
	@RequestMapping("/delete_room/{id}")
	public HashMap<String, Object> deleteHotelRoom(@PathVariable(value = "id") int id) {
		int stat =  hotelRoomRepositoryService.executeDelete(id);
		HashMap<String, Object> map = new HashMap<>();
		map.put("status", stat);
		return map;
	}

}