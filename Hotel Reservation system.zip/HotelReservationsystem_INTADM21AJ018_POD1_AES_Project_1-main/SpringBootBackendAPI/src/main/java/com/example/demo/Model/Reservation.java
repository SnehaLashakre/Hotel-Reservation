package com.example.demo.Model;
//Story_3 from Sprint_1
public class Reservation {
	private long id;
	private String room_id;
	private String arrival;
	private String departure;
	private double room_price;

	private String reservation_status;
	private String book_date;
	private String remark;
	private String user_id;

	public Reservation(long id,  String room_id, String arrival,					//story 3 sprint 1
			String departure, double room_price,  String reservation_status, 
			String book_date, String remark,
			String user_id) {
		super();
		this.id = id;
		
		this.room_id = room_id;
		this.arrival = arrival;
		this.departure = departure;
		this.room_price = room_price;
		
		this.reservation_status = reservation_status;
		this.book_date = book_date;
		this.remark = remark;
		this.user_id = user_id;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}



	public String getRoom_id() {
		return room_id;
	}

	public void setRoom_id(String room_id) {
		this.room_id = room_id;
	}

	public String getArrival() {
		return arrival;
	}

	public void setArrival(String arrival) {
		this.arrival = arrival;
	}

	public String getDeparture() {
		return departure;
	}

	public void setDeparture(String departure) {
		this.departure = departure;
	}

	public double getRoom_price() {
		return room_price;
	}

	public void setRoom_price(double room_price) {
		this.room_price = room_price;
	}



	public String getReservationStatus() {
		return reservation_status;
	}

	public void setReservationStatus(String reservation_status) {
		this.reservation_status = reservation_status;
	}

	public String getBook_date() {
		return book_date;
	}

	public void setBook_date(String book_date) {
		this.book_date = book_date;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	@Override
	public String toString() {
		return "Reservation [id=" + id + ", room_id=" + room_id + ", arrival=" + arrival + ", departure=" + departure
				+ ", room_price=" + room_price  + ", reservation_status=" + reservation_status + ", book_date="
				+ book_date + ", remark=" + remark + ", user_id=" + user_id + "]";
	}

	
}