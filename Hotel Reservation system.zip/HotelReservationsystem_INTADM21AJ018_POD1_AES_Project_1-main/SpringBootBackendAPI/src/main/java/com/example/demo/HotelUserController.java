package com.example.demo;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Model.User;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;
import java.util.Map;
@CrossOrigin
@RestController
public class HotelUserController {
	private static final Logger log = LoggerFactory.getLogger(HotelUserController.class);
	@Autowired
	HotelUserRepositoryService hotelUserRepositoryService;

	/*
	 * 
	 * private String firstName; private String lastName; private String gender;
	 * private String email; private String password; private String mobile; private
	 * String address; private String created; private String role;
	 * 
	 */
	@RequestMapping("/add_user")
	public HashMap<String, Object> addUser(

			@RequestParam("first_name") String first_name, @RequestParam("last_name") String last_name,
			@RequestParam("gender") String gender, @RequestParam("email") String email,
			@RequestParam("password") String password, @RequestParam("mobile") String mobile,
			@RequestParam("address") String address, 
			@RequestParam("role") String role

	) {
		User user = new User(first_name, last_name, gender, email, password, mobile, address,null, role);
		int stat = hotelUserRepositoryService.executeInsert(user);

		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("status", stat);
		return map;
	}
    @RequestMapping("/dash_count")
	public List<Map<String, String>> dash_count()
	{
			return hotelUserRepositoryService.executeJDBCQueryDashCount();

	}



	@RequestMapping("/update_user")
	public HashMap<String, Object> updateUser(@RequestParam("id") int id, @RequestParam("first_name") String first_name,
			@RequestParam("last_name") String last_name, @RequestParam("gender") String gender,
			@RequestParam("email") String email, @RequestParam("password") String password,
			@RequestParam("mobile") String mobile, @RequestParam("address") String address
			

	) {
		User user = new User(id,first_name, last_name, gender, email, password, mobile, address, null, null);
		
		int stat = hotelUserRepositoryService.executeUpdate(user);
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("status", stat);
		return map;
	}

	@RequestMapping("/delete_user/{id}")
	public HashMap<String, Object> deleteUser(@PathVariable("id") int id) {
		int stat = hotelUserRepositoryService.executeDelete(id);
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("status", stat);
		return map;

	}

	@RequestMapping("/users")
	public List<User> retrieveAllUser() {
		return hotelUserRepositoryService.executeJDBCQuery();
	}

	@RequestMapping("/user/{id}")
	public List<User> retrieveUserByid(@PathVariable("id") int id) {
		return hotelUserRepositoryService.executeJDBCQueryById(id);

	}

	@RequestMapping("/userlogin")
	public List<User> login(@RequestParam("username") String username,@RequestParam("password") String password) {
		List<User> users =  hotelUserRepositoryService.executeJDBCQueryLogin(username,password);
		return users;

	}

}